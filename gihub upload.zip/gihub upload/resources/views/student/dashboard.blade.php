@extends('layouts.app')

@section('title', 'Student Dashboard')

@section('content')
<div class="container py-5" style="animation: fadeIn 1s ease;">
    <div class="text-center mb-5">
        <img src="{{ asset('images/psau_logo.png') }}" alt="PSAU Logo" width="80" class="mb-2">
        <h2 class="fw-bold text-success">Student Dashboard</h2>
        <p class="text-muted">Welcome, {{ Auth::user()->name }} 🎓</p>
    </div>

    <div class="row g-4">
        <div class="col-md-6">
            <div class="card shadow border-0 h-100">
                <div class="card-body text-center">
                    <h5 class="card-title fw-bold text-success">🧠 Take Quiz</h5>
                    <p class="text-muted">Answer available quizzes from your teachers.</p>
                    <a href="{{ route('results.index') }}" class="btn btn-success w-100">Start Quiz</a>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow border-0 h-100">
                <div class="card-body text-center">
                    <h5 class="card-title fw-bold text-success">📋 My Scores</h5>
                    <p class="text-muted">View all your past quiz results and scores.</p>
                    <a href="{{ route('results.myScores') }}" class="btn btn-success w-100">View Scores</a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
@endsection
