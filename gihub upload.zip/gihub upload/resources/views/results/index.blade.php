@extends('layouts.app')

@section('title', 'Available Quizzes')

@section('content')
    <div class="container mt-4">
        <h1 class="mb-4">Available Quizzes</h1>

        @if ($quizzes->count() > 0)
            <ul class="list-group mb-3">
                @foreach ($quizzes as $quiz)
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="{{ route('results.show', $quiz->id) }}" class="fw-bold text-decoration-none">
                            {{ $quiz->title }}</a>
                             @if ($quiz->deadline)
                             <span class="text-sm text-gray-500">
                                (Deadline: {{ \Carbon\Carbon::parse($quiz->deadline)->format('M d, Y h:i A') }})
                            </span>
                            @endif
                        </li>
                        <span class="badge bg-primary">Take Quiz</span>
                    </li>
                @endforeach
            </ul>
        @else
            <div class="alert alert-info">No quizzes available at the moment.</div>
        @endif

        <a href="{{ route('student.dashboard') }}" class="btn btn-secondary mt-3">Back to Dashboard</a>
    </div>
@endsection
