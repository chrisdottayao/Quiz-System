@extends('layouts.app')

@section('title', 'Quiz')

@section('content')
    <h1>{{ $quiz->title }}</h1>
    <p>{{ $quiz->description }}</p>

    <form method="POST" action="{{ route('results.store') }}">
        @csrf
        <input type="hidden" name="quiz_id" value="{{ $quiz->id }}">

        @foreach ($quiz->questions as $question)
            <div>
                <p><strong>{{ $question->question_text }}</strong></p>
                <label><input type="radio" name="question_{{ $question->id }}" value="A"> A. {{ $question->option_a }}</label><br>
                <label><input type="radio" name="question_{{ $question->id }}" value="B"> B. {{ $question->option_b }}</label><br>
                @if ($question->option_c)
                    <label><input type="radio" name="question_{{ $question->id }}" value="C"> C. {{ $question->option_c }}</label><br>
                @endif
                @if ($question->option_d)
                    <label><input type="radio" name="question_{{ $question->id }}" value="D"> D. {{ $question->option_d }}</label><br>
                @endif
            </div>
            <hr>
        @endforeach

        <button type="submit">Submit Answers</button>
    </form>

    <a href="{{ route('results.index') }}">Back</a>
@endsection
