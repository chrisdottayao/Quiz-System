@extends('layouts.app')

@section('title', 'My Scores')

@section('content')
<div class="card p-4 shadow">
    <h2 class="mb-4 text-success">My Quiz Scores</h2>

    @if ($results->count() > 0)
        <table class="table table-striped">
            <thead class="table-primary">
                <tr>
                    <th>Quiz Title</th>
                    <th>Score</th>
                    <th>Date Taken</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($results as $result)
                    <tr>
                        <td>{{ $result->quiz->title }}</td>
                        <td>{{ $result->score }}</td>
                        <td>{{ $result->created_at->format('Y-m-d H:i') }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <div class="alert alert-info">You haven’t taken any quizzes yet.</div>
    @endif

    <a href="{{ route('student.dashboard') }}" class="btn btn-secondary mt-3">Back to Dashboard</a>
</div>
@endsection
