@extends('layouts.app')

@section('title', 'Available Quizzes')

@section('content')
<div class="card p-4 shadow">
    <h2 class="mb-4 text-primary">Available Quizzes</h2>
@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif
    @if ($quizzes->count() > 0)
        <ul class="list-group mb-3">
@foreach ($quizzes as $quiz)
    <li class="d-flex justify-content-between align-items-center mb-2">
        <span>
            <a href="{{ route('quizzes.show', $quiz->id) }}" class="fw-bold text-success">{{ $quiz->title }}</a>
            @if ($quiz->deadline)
    <small class="text-muted">Deadline: {{ \Carbon\Carbon::parse($quiz->deadline)->format('M d, Y - h:i A') }}</small>
            @endif
        </span>
        <a href="{{ route('quizzes.edit', $quiz->id) }}" class="btn btn-sm btn-warning">✏️ Edit</a>
        <form action="{{ route('quizzes.destroy', $quiz->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this quiz?');">
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-sm btn-danger">🗑 Delete</button>
        </form>
    </li>
@endforeach

        </ul>
    @else
        <div class="alert alert-info">No quizzes available yet.</div>
    @endif

<a href="{{ auth()->user()->role === 'teacher' ? route('teacher.dashboard') : route('student.dashboard') }}" 
   class="btn btn-secondary mt-3">
   Back to Dashboard
</a>
</div>
@endsection
