@extends('layouts.app')

@section('title', 'Student Result')

@section('content')
    <h1>Results for {{ $user->name }}</h1>

    @if ($results->count() > 0)
        <table border="1" cellpadding="8">
            <thead>
                <tr>
                    <th>Quiz Title</th>
                    <th>Score</th>
                    <th>Date Taken</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($results as $result)
                    <tr>
                        <td>{{ $result->quiz->title }}</td>
                        <td>{{ $result->score }}</td>
                        <td>{{ $result->created_at->format('Y-m-d H:i') }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <p>No results found for this student.</p>
    @endif

    <br>
    <a href="{{ route('teacher.dashboard') }}">Back to Teacher Dashboard</a>
@endsection
