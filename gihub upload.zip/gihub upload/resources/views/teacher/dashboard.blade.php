@extends('layouts.app')

@section('title', 'Teacher Dashboard')

@section('content')
<div class="container py-5" style="animation: fadeIn 1s ease;">
    <div class="text-center mb-5">
        <img src="{{ asset('images/psau_logo.png') }}" alt="PSAU Logo" width="80" class="mb-2">
        <h2 class="fw-bold text-success">Teacher Dashboard</h2>
        <p class="text-muted">Welcome, {{ Auth::user()->name }} 👋</p>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="card shadow border-0 h-100">
                <div class="card-body text-center">
                    <h5 class="card-title fw-bold text-success">📝 Manage Quizzes</h5>
                    <p class="text-muted">Create, edit, and delete quizzes for your students.</p>
                    <a href="{{ route('quizzes.index') }}" class="btn btn-success w-100">Go to Quizzes</a>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow border-0 h-100">
                <div class="card-body text-center">
                    <h5 class="card-title fw-bold text-success">📊 View Results</h5>
                    <p class="text-muted">Check your students' performance and export results.</p>
                    <a href="{{ route('results.all') }}" class="btn btn-success w-100">View Results</a>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow border-0 h-100">
                <div class="card-body text-center">
                    <h5 class="card-title fw-bold text-success">👤 Profile</h5>
                    <p class="text-muted">Update your information and view your account details.</p>
                    <a href="{{ route('profile') }}" class="btn btn-success w-100">View Profile</a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
@endsection
